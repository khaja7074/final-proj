package carDoor1;




import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;



@WebServlet("/firstservlet")
public class cart extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try {
			res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			//pw.println("This is eg of include");
			res.setContentType("text/html");
			//PrintWriter pw=res.getWriter();			
			String s=req.getParameter("t1");
			
			//String t=req.getParameter("num");
			//String u=req.getParameter("Bike");
			//String v=req.getParameter("Car");
			//String w=req.getParameter("Boat");
			//String x=req.getParameter("audi");
//			pw.println("<html>");
//	        pw.println("<head>");
//	        pw.println("<title>Cart</title>");
//	        pw.println("</head>");
//	        pw.println("<body>");
//	        pw.println("<h1>");
//	        pw.println("<center>");
//	        pw.println("Thank you");
//	        
//	        pw.println("\n");
//	        pw.println(s);
//	        pw.println("</center>");
//	        pw.println("</h1>");
//	       pw.println("<br>");pw.println("<h3>");
//	       pw.println("Enjoy your meal!");
//	       pw.println("</h3>");
		//	pw.println("PhoneNo: "+t);
			// pw.println("<br>");
			// pw.println("selected car: " +u);
//			
//	        pw.println("</body>");
//	        pw.println("");
//			
			//RequestDispatcher rd=req.getRequestDispatcher("/restaurants.html");
			//rd.include(req, res);
			//pw.close();
			String trans[] = req.getParameterValues("trans") ;
		     
		     PrintWriter writer =  res.getWriter();
		     //res.setContentType("text/html");
		     writer.println("<h2><font color=green>Your Location :</font></h2>");
		     writer.println(s);
		     writer.println("<table><tr><td>Item</td>"
		     		+ "<td>Rate</td></tr>");
		     //writer.println("<tr>");
		    /* for(String value : trans)
		     {
		     writer.println("<tr><br><font color=blue>"+value+"</font></tr>");
		     }  */
		    // writer.println("</tr></table>");
		     
		     
		     String[] assignedResources = req.getParameterValues("trans");
		     int total=0,t;
		     
		     if (assignedResources != null) {
		         for(String item: assignedResources){
		             String keyValue[]= item.split(":");
		             pw.println(keyValue[0]);
		             
		             pw.println( keyValue[1]);
		             pw.println("<br>");
		             t=Integer.parseInt(keyValue[1]);
		             total=t+total;
		             
		            
		         }
		        
		     }
	
		     pw.println("Total:" +total);
		     writer.close();
		    
		}
		catch(Exception ae) {
		
	}


	}

}