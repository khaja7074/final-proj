package carDoor1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class logins
 */
@WebServlet("/logins")
public class logins extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
               String un = request.getParameter("username");
               String pw = request.getParameter("password");
               PrintWriter out = response.getWriter();  
       // Connect to mysql(mariadb) and verify username password

               
           	try{
           		Connection con=null;
           		Class.forName("oracle.jdbc.driver.OracleDriver");
           		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
           	 
    			PreparedStatement ps=con.prepareStatement("select * from reg where username=? and password=?");
    			ps.setString(1,un);
    			ps.setString(2,pw);
    			ResultSet rs=ps.executeQuery();
    			if(rs.next()){
    				 
    	           			HttpSession session=request.getSession();
    	           			session.setAttribute("username",un);
    	           			request.getRequestDispatcher("car-without-sidebar1.jsp").include(request, response);
    	           				
    	           		}else{
    	           			out.println("<div class='container'>");
       	       	         
    	           			out.println("<h1>Username or password error</h1>");
    	          		request.getRequestDispatcher("4042.html").include(request, response);
    	           		    out.println("</div>");
    	           			

    	           		}
    			

    			con.close();
           		
           		
           		
           		
           	}catch(Exception e){System.out.println(e);}
           	
                   
                   
                   
                  
                    
                  
           
               
           }
	}

	
	


